package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.FootballRepository
import com.example.ui.FootballViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Kooora Live", appName)
    }

    @Test
    fun `test football repository data and live simulation`() {
        val repo = FootballRepository()
        val initialMatches = repo.matches.value
        assertTrue("Should contain initial matches", initialMatches.isNotEmpty())

        val elClasico = initialMatches.find { it.id == "m1" }
        assertTrue("El Clasico match should exist", elClasico != null)

        repo.simulateLiveTick()
        val updatedClasico = repo.matches.value.find { it.id == "m1" }
        assertTrue("Match should still exist after live tick", updatedClasico != null)
    }

    @Test
    fun `test toggle favorites`() {
        val repo = FootballRepository()
        val matchId = "m2"
        val initiallyFav = repo.favoriteMatchIds.value.contains(matchId)
        repo.toggleFavorite(matchId)
        assertEquals(!initiallyFav, repo.favoriteMatchIds.value.contains(matchId))
    }
}
