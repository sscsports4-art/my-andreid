package com.example.model

enum class MatchStatus {
    LIVE,
    FINISHED,
    UPCOMING,
    HALFTIME
}

enum class EventType {
    GOAL,
    PENALTY_GOAL,
    OWN_GOAL,
    YELLOW_CARD,
    RED_CARD,
    SUBSTITUTION,
    VAR_DECISION
}

data class Competition(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val country: String,
    val flag: String,
    val order: Int
)

data class Team(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val shortName: String,
    val primaryColor: Long,
    val secondaryColor: Long,
    val initials: String,
    val country: String
)

data class MatchEvent(
    val minute: String,
    val type: EventType,
    val player: String,
    val teamId: String,
    val assistPlayer: String? = null,
    val detail: String? = null
)

data class MatchStats(
    val possessionHome: Int,
    val possessionAway: Int,
    val shotsHome: Int,
    val shotsAway: Int,
    val shotsOnTargetHome: Int,
    val shotsOnTargetAway: Int,
    val xGHome: Float,
    val xGAway: Float,
    val cornersHome: Int,
    val cornersAway: Int,
    val foulsHome: Int,
    val foulsAway: Int,
    val offsidesHome: Int,
    val offsidesAway: Int,
    val yellowCardsHome: Int,
    val yellowCardsAway: Int,
    val redCardsHome: Int,
    val redCardsAway: Int,
    val passesAccuracyHome: Int,
    val passesAccuracyAway: Int
)

data class PlayerLineup(
    val number: Int,
    val nameAr: String,
    val position: String, // GK, DF, MF, FW
    val rating: Float,
    val isCaptain: Boolean = false,
    val isSub: Boolean = false,
    val goalsScored: Int = 0
)

data class MatchLineup(
    val formationHome: String,
    val formationAway: String,
    val startingHome: List<PlayerLineup>,
    val startingAway: List<PlayerLineup>,
    val benchHome: List<PlayerLineup>,
    val benchAway: List<PlayerLineup>,
    val coachHome: String,
    val coachAway: String
)

data class H2HEntry(
    val date: String,
    val competition: String,
    val homeTeamName: String,
    val awayTeamName: String,
    val homeScore: Int,
    val awayScore: Int
)

data class Match(
    val id: String,
    val competitionId: String,
    val round: String,
    val homeTeam: Team,
    val awayTeam: Team,
    val homeScore: Int?,
    val awayScore: Int?,
    val status: MatchStatus,
    val liveMinute: String,
    val matchDate: String, // "TODAY", "YESTERDAY", "TOMORROW"
    val matchTime: String,
    val stadium: String,
    val referee: String,
    val events: List<MatchEvent>,
    val stats: MatchStats,
    val lineup: MatchLineup,
    val h2h: List<H2HEntry>,
    val isFavorite: Boolean = false
)

data class StandingEntry(
    val rank: Int,
    val team: Team,
    val played: Int,
    val won: Int,
    val drawn: Int,
    val lost: Int,
    val goalsFor: Int,
    val goalsAgainst: Int,
    val points: Int,
    val form: List<Char> // 'W', 'D', 'L'
) {
    val goalDifference: Int get() = goalsFor - goalsAgainst
}

data class TopScorer(
    val rank: Int,
    val playerName: String,
    val team: Team,
    val goals: Int,
    val assists: Int,
    val penalties: Int,
    val matches: Int
)

data class FootballNews(
    val id: String,
    val titleAr: String,
    val summaryAr: String,
    val category: String,
    val timeAgo: String,
    val readTime: String,
    val hotTopic: Boolean = false
)
