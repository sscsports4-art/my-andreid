package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FootballRepository {

    val competitions = listOf(
        Competition("ucl", "دوري أبطال أوروبا", "Champions League", "أوروبا", "🏆", 1),
        Competition("epl", "الدوري الإنجليزي", "Premier League", "إنجلترا", "🏴󠁧󠁢󠁥󠁮󠁧󠁿", 2),
        Competition("laliga", "الدوري الإسباني", "La Liga", "إسبانيا", "🇪🇸", 3),
        Competition("roshn", "دوري روشن السعودي", "Saudi Pro League", "السعودية", "🇸🇦", 4),
        Competition("seriea", "الدوري الإيطالي", "Serie A", "إيطاليا", "🇮🇹", 5)
    )

    val teams = mapOf(
        "rm" to Team("rm", "ريال مدريد", "Real Madrid", "RMA", 0xFFFFFFFF, 0xFF00529F, "RMA", "إسبانيا"),
        "bar" to Team("bar", "برشلونة", "Barcelona", "FCB", 0xFF004D98, 0xFFA50044, "FCB", "إسبانيا"),
        "mci" to Team("mci", "مانشستر سيتي", "Man City", "MCI", 0xFF6CABDD, 0xFF1C2C5B, "MCI", "إنجلترا"),
        "liv" to Team("liv", "ليفربول", "Liverpool", "LIV", 0xFFC8102E, 0xFF00B2A9, "LIV", "إنجلترا"),
        "ars" to Team("ars", "أرسنال", "Arsenal", "ARS", 0xFFEF0107, 0xFF063672, "ARS", "إنجلترا"),
        "bay" to Team("bay", "بايرن ميونخ", "Bayern Munich", "BAY", 0xFFDC052D, 0xFF0066B2, "BAY", "ألمانيا"),
        "psg" to Team("psg", "باريس سان جيرمان", "PSG", "PSG", 0xFF004170, 0xFFDA291C, "PSG", "فرنسا"),
        "hil" to Team("hil", "الهلال", "Al-Hilal", "HIL", 0xFF0B52A1, 0xFFFFFFFF, "HIL", "السعودية"),
        "nas" to Team("nas", "النصر", "Al-Nassr", "NAS", 0xFFFFD700, 0xFF0038A8, "NAS", "السعودية"),
        "itt" to Team("itt", "الاتحاد", "Al-Ittihad", "ITT", 0xFFFFD200, 0xFF000000, "ITT", "السعودية"),
        "int" to Team("int", "إنتر ميلان", "Inter Milan", "INT", 0xFF001EA0, 0xFF000000, "INT", "إيطاليا"),
        "mil" to Team("mil", "ميلان", "AC Milan", "MIL", 0xFFAC0000, 0xFF000000, "MIL", "إيطاليا"),
        "atm" to Team("atm", "أتلتيكو مدريد", "Atletico Madrid", "ATM", 0xFFCB3524, 0xFF272E61, "ATM", "إسبانيا"),
        "che" to Team("che", "تشيلسي", "Chelsea", "CHE", 0xFF034694, 0xFFEE242C, "CHE", "إنجلترا")
    )

    private val _matches = MutableStateFlow<List<Match>>(createInitialMatches())
    val matches: StateFlow<List<Match>> = _matches.asStateFlow()

    private val _favoriteMatchIds = MutableStateFlow<Set<String>>(setOf("m1", "m3"))
    val favoriteMatchIds: StateFlow<Set<String>> = _favoriteMatchIds.asStateFlow()

    fun toggleFavorite(matchId: String) {
        val current = _favoriteMatchIds.value.toMutableSet()
        if (current.contains(matchId)) {
            current.remove(matchId)
        } else {
            current.add(matchId)
        }
        _favoriteMatchIds.value = current
    }

    fun simulateLiveTick() {
        val list = _matches.value.map { match ->
            if (match.status == MatchStatus.LIVE) {
                val currentMin = match.liveMinute.replace("'", "").replace("+", "").toIntOrNull() ?: 75
                val nextMin = if (currentMin < 90) currentMin + 1 else 90
                val nextStatus = if (nextMin >= 90) MatchStatus.FINISHED else MatchStatus.LIVE
                val nextScoreAway = if (match.id == "m1" && nextMin == 82) (match.awayScore ?: 1) + 1 else match.awayScore
                val updatedEvents = if (match.id == "m1" && nextMin == 82) {
                    match.events + MatchEvent("82'", EventType.GOAL, "لامين يامال", "bar", "رافينيا", "تسديدة مقوسة رائعة")
                } else match.events

                match.copy(
                    liveMinute = "$nextMin'",
                    status = nextStatus,
                    awayScore = nextScoreAway,
                    events = updatedEvents
                )
            } else {
                match
            }
        }
        _matches.value = list
    }

    private fun createInitialMatches(): List<Match> {
        val rm = teams["rm"]!!
        val bar = teams["bar"]!!
        val mci = teams["mci"]!!
        val liv = teams["liv"]!!
        val hil = teams["hil"]!!
        val nas = teams["nas"]!!
        val bay = teams["bay"]!!
        val psg = teams["psg"]!!
        val ars = teams["ars"]!!
        val che = teams["che"]!!
        val int = teams["int"]!!
        val mil = teams["mil"]!!
        val itt = teams["itt"]!!
        val atm = teams["atm"]!!

        return listOf(
            // MATCH 1: Live El Clásico
            Match(
                id = "m1",
                competitionId = "laliga",
                round = "الجولة 29",
                homeTeam = rm,
                awayTeam = bar,
                homeScore = 2,
                awayScore = 1,
                status = MatchStatus.LIVE,
                liveMinute = "78'",
                matchDate = "TODAY",
                matchTime = "22:00",
                stadium = "ملعب سانتياغو برنابيو (مدريد)",
                referee = "خيل مانزانو",
                events = listOf(
                    MatchEvent("14'", EventType.GOAL, "فينيسيوس جونيور", "rm", "جود بيلينغهام", "انفراد وتسديدة أرضية"),
                    MatchEvent("38'", EventType.YELLOW_CARD, "غافي", "bar", null, "تدخل قوي بالوسط"),
                    MatchEvent("53'", EventType.GOAL, "روبرت ليفاندوفسكي", "bar", "بيدري", "رأسية متقنة في الشباك"),
                    MatchEvent("67'", EventType.GOAL, "كيليان مبابي", "rm", "فيديريكو فالفيردي", "صاروخية في المقص الأيمن"),
                    MatchEvent("72'", EventType.SUBSTITUTION, "لوكا مودريتش", "rm", "رودريغو", "تبديل تكتيكي")
                ),
                stats = MatchStats(
                    possessionHome = 54, possessionAway = 46,
                    shotsHome = 14, shotsAway = 10,
                    shotsOnTargetHome = 6, shotsOnTargetAway = 4,
                    xGHome = 2.14f, xGAway = 1.38f,
                    cornersHome = 5, cornersAway = 3,
                    foulsHome = 9, foulsAway = 12,
                    offsidesHome = 2, offsidesAway = 3,
                    yellowCardsHome = 1, yellowCardsAway = 2,
                    redCardsHome = 0, redCardsAway = 0,
                    passesAccuracyHome = 89, passesAccuracyAway = 86
                ),
                lineup = MatchLineup(
                    formationHome = "4-3-3",
                    formationAway = "4-2-3-1",
                    startingHome = listOf(
                        PlayerLineup(1, "تيبو كورتوا", "GK", 7.6f),
                        PlayerLineup(2, "داني كارفاخال", "DF", 7.4f, isCaptain = true),
                        PlayerLineup(3, "إيدير ميليتاو", "DF", 7.1f),
                        PlayerLineup(22, "أنطونيو روديغر", "DF", 7.8f),
                        PlayerLineup(23, "فيرلاند ميندي", "DF", 6.9f),
                        PlayerLineup(8, "فيديريكو فالفيردي", "MF", 8.2f),
                        PlayerLineup(14, "أوريلين تشواميني", "MF", 7.3f),
                        PlayerLineup(5, "جود بيلينغهام", "MF", 8.5f),
                        PlayerLineup(11, "رودريغو غوس", "FW", 7.0f),
                        PlayerLineup(9, "كيليان مبابي", "FW", 8.7f, goalsScored = 1),
                        PlayerLineup(7, "فينيسيوس جونيور", "FW", 8.9f, goalsScored = 1)
                    ),
                    startingAway = listOf(
                        PlayerLineup(1, "مارك أندريه تير شتيغن", "GK", 7.1f, isCaptain = true),
                        PlayerLineup(23, "جول كوندي", "DF", 7.2f),
                        PlayerLineup(2, "باو كوبارسي", "DF", 6.8f),
                        PlayerLineup(5, "إينيغو مارتينيز", "DF", 6.7f),
                        PlayerLineup(3, "أليخاندرو بالدي", "DF", 7.0f),
                        PlayerLineup(8, "بيدري", "MF", 8.1f),
                        PlayerLineup(21, "فرينكي دي يونغ", "MF", 7.5f),
                        PlayerLineup(19, "لامين يامال", "FW", 8.4f),
                        PlayerLineup(6, "غافي", "MF", 6.9f),
                        PlayerLineup(11, "رافينيا", "FW", 7.7f),
                        PlayerLineup(9, "روبرت ليفاندوفسكي", "FW", 8.0f, goalsScored = 1)
                    ),
                    benchHome = listOf(
                        PlayerLineup(10, "لوكا مودريتش", "MF", 7.2f, isSub = true),
                        PlayerLineup(15, "أردا غولر", "MF", 6.8f),
                        PlayerLineup(16, "إندريك", "FW", 6.9f),
                        PlayerLineup(13, "أندريه لونين", "GK", 6.5f)
                    ),
                    benchAway = listOf(
                        PlayerLineup(7, "فيران توريس", "FW", 6.7f),
                        PlayerLineup(16, "فيرمين لوبيز", "MF", 6.8f),
                        PlayerLineup(17, "مارك كاسادو", "MF", 6.6f),
                        PlayerLineup(13, "إينياكي بينيا", "GK", 6.4f)
                    ),
                    coachHome = "كارلو أنشيلوتي",
                    coachAway = "هانز فليك"
                ),
                h2h = listOf(
                    H2HEntry("2024-10-26", "الدوري الإسباني", "ريال مدريد", "برشلونة", 0, 4),
                    H2HEntry("2024-04-21", "الدوري الإسباني", "ريال مدريد", "برشلونة", 3, 2),
                    H2HEntry("2024-01-14", "السوبر الإسباني", "ريال مدريد", "برشلونة", 4, 1),
                    H2HEntry("2023-10-28", "الدوري الإسباني", "برشلونة", "ريال مدريد", 1, 2)
                )
            ),

            // MATCH 2: Live Saudi Derby Al Hilal vs Al Nassr
            Match(
                id = "m2",
                competitionId = "roshn",
                round = "الجولة 26",
                homeTeam = hil,
                awayTeam = nas,
                homeScore = 2,
                awayScore = 2,
                status = MatchStatus.LIVE,
                liveMinute = "84'",
                matchDate = "TODAY",
                matchTime = "21:00",
                stadium = "المملكة أرينا (الرياض)",
                referee = "ويلمار رولدان",
                events = listOf(
                    MatchEvent("18'", EventType.GOAL, "ألكسندر ميتروفيتش", "hil", "سالم الدوسري", "ضربة رأسية لا تصد"),
                    MatchEvent("33'", EventType.GOAL, "كريستيانو رونالدو", "nas", "ساديو ماني", "تسديدة مباغتة من خارج المنطقة"),
                    MatchEvent("45+2'", EventType.YELLOW_CARD, "إيمريك لابورت", "nas", null, "عرقلة لميتروفيتش"),
                    MatchEvent("61'", EventType.GOAL, "سالم الدوسري", "hil", "روبن نيفيز", "مراوغة فردية ولمسة ساحرة"),
                    MatchEvent("77'", EventType.PENALTY_GOAL, "كريستيانو رونالدو", "nas", null, "تنفيذ ركلة جزاء بدقة")
                ),
                stats = MatchStats(
                    possessionHome = 52, possessionAway = 48,
                    shotsHome = 13, shotsAway = 12,
                    shotsOnTargetHome = 5, shotsOnTargetAway = 6,
                    xGHome = 1.92f, xGAway = 2.10f,
                    cornersHome = 6, cornersAway = 5,
                    foulsHome = 11, foulsAway = 14,
                    offsidesHome = 1, offsidesAway = 2,
                    yellowCardsHome = 2, yellowCardsAway = 3,
                    redCardsHome = 0, redCardsAway = 0,
                    passesAccuracyHome = 87, passesAccuracyAway = 84
                ),
                lineup = MatchLineup(
                    formationHome = "4-2-3-1",
                    formationAway = "4-3-3",
                    startingHome = listOf(
                        PlayerLineup(37, "ياسين بونو", "GK", 8.2f),
                        PlayerLineup(66, "سعود عبد الحميد", "DF", 7.4f),
                        PlayerLineup(3, "خاليدو كوليبالي", "DF", 7.5f),
                        PlayerLineup(5, "علي البليهي", "DF", 7.1f),
                        PlayerLineup(12, "ياسر الشهراني", "DF", 7.0f),
                        PlayerLineup(8, "روبن نيفيز", "MF", 8.3f),
                        PlayerLineup(22, "سيرجي سافيتش", "MF", 8.0f),
                        PlayerLineup(77, "مالكوم", "FW", 7.6f),
                        PlayerLineup(10, "نيمار جونيور", "MF", 7.8f),
                        PlayerLineup(29, "سالم الدوسري", "FW", 8.8f, isCaptain = true, goalsScored = 1),
                        PlayerLineup(9, "ألكسندر ميتروفيتش", "FW", 8.6f, goalsScored = 1)
                    ),
                    startingAway = listOf(
                        PlayerLineup(24, "بينتو", "GK", 7.2f),
                        PlayerLineup(2, "سلطان الغنام", "DF", 7.3f),
                        PlayerLineup(27, "إيمريك لابورت", "DF", 7.0f),
                        PlayerLineup(3, "محمد سيماكان", "DF", 7.1f),
                        PlayerLineup(13, "أليكس تيليس", "DF", 6.9f),
                        PlayerLineup(17, "عبد الله الخيبري", "MF", 7.2f),
                        PlayerLineup(25, "أوتافيو", "MF", 8.1f),
                        PlayerLineup(77, "مارسيلو بروزوفيتش", "MF", 8.0f),
                        PlayerLineup(94, "أندرسون تاليسكا", "FW", 7.5f),
                        PlayerLineup(10, "ساديو ماني", "FW", 8.2f),
                        PlayerLineup(7, "كريستيانو رونالدو", "FW", 9.1f, isCaptain = true, goalsScored = 2)
                    ),
                    benchHome = listOf(
                        PlayerLineup(28, "محمد كنو", "MF", 7.0f),
                        PlayerLineup(99, "عبد الله الحمدان", "FW", 6.8f),
                        PlayerLineup(21, "محمد العويس", "GK", 6.5f)
                    ),
                    benchAway = listOf(
                        PlayerLineup(29, "عبد الرحمن غريب", "FW", 7.2f),
                        PlayerLineup(8, "عبد المجيد الصليهم", "MF", 6.7f),
                        PlayerLineup(33, "وليد عبد الله", "GK", 6.4f)
                    ),
                    coachHome = "جورجي جيسوس",
                    coachAway = "ستيفانو بيولي"
                ),
                h2h = listOf(
                    H2HEntry("2024-05-31", "كأس خادم الحرمين", "الهلال", "النصر", 1, 1),
                    H2HEntry("2024-04-08", "كأس السوبر السعودي", "الهلال", "النصر", 2, 1),
                    H2HEntry("2023-12-01", "دوري روشن", "الهلال", "النصر", 3, 0)
                )
            ),

            // MATCH 3: Premier League Man City vs Liverpool
            Match(
                id = "m3",
                competitionId = "epl",
                round = "الجولة 31",
                homeTeam = mci,
                awayTeam = liv,
                homeScore = 3,
                awayScore = 2,
                status = MatchStatus.FINISHED,
                liveMinute = "FT",
                matchDate = "TODAY",
                matchTime = "18:30",
                stadium = "استاد الاتحاد (مانشستر)",
                referee = "مايكل أوليفر",
                events = listOf(
                    MatchEvent("9'", EventType.GOAL, "إرلينغ هالاند", "mci", "كيفين دي بروين", "تسديدة صاروخية يسارية"),
                    MatchEvent("27'", EventType.GOAL, "محمد صلاح", "liv", "ترينت ألكسندر أرنولد", "عرضية متقنة ولمسة في الشباك"),
                    MatchEvent("41'", EventType.GOAL, "فيل فودين", "mci", "برناردو سيلفا", "مجهود فردي مذهل"),
                    MatchEvent("65'", EventType.GOAL, "لويس دياز", "liv", "ماك أليستر", "انقضاض سريع بالمرتدة"),
                    MatchEvent("88'", EventType.GOAL, "إرلينغ هالاند", "mci", "جيريمي دوكو", "هدف الفوز القاتل بالدقيقة 88")
                ),
                stats = MatchStats(
                    possessionHome = 61, possessionAway = 39,
                    shotsHome = 18, shotsAway = 11,
                    shotsOnTargetHome = 8, shotsOnTargetAway = 5,
                    xGHome = 2.85f, xGAway = 1.94f,
                    cornersHome = 8, cornersAway = 4,
                    foulsHome = 8, foulsAway = 10,
                    offsidesHome = 3, offsidesAway = 1,
                    yellowCardsHome = 1, yellowCardsAway = 2,
                    redCardsHome = 0, redCardsAway = 0,
                    passesAccuracyHome = 91, passesAccuracyAway = 82
                ),
                lineup = MatchLineup(
                    formationHome = "4-1-4-1",
                    formationAway = "4-3-3",
                    startingHome = listOf(
                        PlayerLineup(31, "إيدرسون مورايس", "GK", 7.4f),
                        PlayerLineup(2, "كايل ووكر", "DF", 7.5f, isCaptain = true),
                        PlayerLineup(3, "روبن دياز", "DF", 7.9f),
                        PlayerLineup(25, "مانويل أكانجي", "DF", 7.6f),
                        PlayerLineup(24, "يوشكو غفارديول", "DF", 7.7f),
                        PlayerLineup(16, "رودري", "MF", 8.8f),
                        PlayerLineup(20, "برناردو سيلفا", "MF", 8.3f),
                        PlayerLineup(17, "كيفين دي بروين", "MF", 8.7f),
                        PlayerLineup(47, "فيل فودين", "MF", 8.6f, goalsScored = 1),
                        PlayerLineup(11, "جيريمي دوكو", "FW", 8.1f),
                        PlayerLineup(9, "إرلينغ هالاند", "FW", 9.4f, goalsScored = 2)
                    ),
                    startingAway = listOf(
                        PlayerLineup(1, "أليسون بيكر", "GK", 7.5f),
                        PlayerLineup(66, "ترينت ألكسندر أرنولد", "DF", 7.8f),
                        PlayerLineup(5, "إبراهيما كوناتي", "DF", 7.1f),
                        PlayerLineup(4, "فيرجيل فان دايك", "DF", 7.8f, isCaptain = true),
                        PlayerLineup(26, "أندي روبرتسون", "DF", 7.2f),
                        PlayerLineup(10, "أليكسيس ماك أليستر", "MF", 8.0f),
                        PlayerLineup(38, "ريان جرافينبيرخ", "MF", 7.6f),
                        PlayerLineup(8, "دومينيك سوبوسلاي", "MF", 7.4f),
                        PlayerLineup(11, "محمد صلاح", "FW", 8.6f, goalsScored = 1),
                        PlayerLineup(9, "داروين نونيز", "FW", 7.1f),
                        PlayerLineup(7, "لويس دياز", "FW", 8.2f, goalsScored = 1)
                    ),
                    benchHome = listOf(
                        PlayerLineup(8, "ماتيو كوفاسيتش", "MF", 7.0f),
                        PlayerLineup(10, "جاك غريليش", "FW", 7.2f),
                        PlayerLineup(18, "ستيفان أورتيغا", "GK", 6.5f)
                    ),
                    benchAway = listOf(
                        PlayerLineup(18, "كودي جاكبو", "FW", 7.0f),
                        PlayerLineup(17, "كورتيس جونز", "MF", 6.9f),
                        PlayerLineup(62, "كاويمين كيليهير", "GK", 6.6f)
                    ),
                    coachHome = "بيب غوارديولا",
                    coachAway = "أرني سلوت"
                ),
                h2h = listOf(
                    H2HEntry("2024-03-10", "الدوري الإنجليزي", "ليفربول", "مانشستر سيتي", 1, 1),
                    H2HEntry("2023-11-25", "الدوري الإنجليزي", "مانشستر سيتي", "ليفربول", 1, 1),
                    H2HEntry("2023-04-01", "الدوري الإنجليزي", "مانشستر سيتي", "ليفربول", 4, 1)
                )
            ),

            // MATCH 4: Champions League Bayern Munich vs PSG
            Match(
                id = "m4",
                competitionId = "ucl",
                round = "ربع النهائي - ذهاب",
                homeTeam = bay,
                awayTeam = psg,
                homeScore = null,
                awayScore = null,
                status = MatchStatus.UPCOMING,
                liveMinute = "",
                matchDate = "TODAY",
                matchTime = "23:00",
                stadium = "أليانز أرينا (ميونخ)",
                referee = "دانييلي أورساتو",
                events = emptyList(),
                stats = MatchStats(
                    possessionHome = 50, possessionAway = 50,
                    shotsHome = 0, shotsAway = 0,
                    shotsOnTargetHome = 0, shotsOnTargetAway = 0,
                    xGHome = 0f, xGAway = 0f,
                    cornersHome = 0, cornersAway = 0,
                    foulsHome = 0, foulsAway = 0,
                    offsidesHome = 0, offsidesAway = 0,
                    yellowCardsHome = 0, yellowCardsAway = 0,
                    redCardsHome = 0, redCardsAway = 0,
                    passesAccuracyHome = 0, passesAccuracyAway = 0
                ),
                lineup = MatchLineup(
                    formationHome = "4-2-3-1",
                    formationAway = "4-3-3",
                    startingHome = listOf(
                        PlayerLineup(1, "مانويل نوير", "GK", 8.0f, isCaptain = true),
                        PlayerLineup(2, "دايوت أوباميكانو", "DF", 7.5f),
                        PlayerLineup(3, "كيم مين جاي", "DF", 7.6f),
                        PlayerLineup(19, "ألفونسو ديفيز", "DF", 8.1f),
                        PlayerLineup(6, "جوشوا كيميتش", "MF", 8.4f),
                        PlayerLineup(42, "جمال موسيالا", "MF", 8.8f),
                        PlayerLineup(9, "هاري كين", "FW", 9.0f)
                    ),
                    startingAway = listOf(
                        PlayerLineup(1, "جيانلويجي دوناروما", "GK", 8.1f),
                        PlayerLineup(2, "أشرف حكيمي", "DF", 8.5f),
                        PlayerLineup(5, "ماركينيوس", "DF", 8.0f, isCaptain = true),
                        PlayerLineup(10, "عثمان ديمبيلي", "FW", 8.3f),
                        PlayerLineup(29, "برادلي باركولا", "FW", 8.2f)
                    ),
                    benchHome = emptyList(),
                    benchAway = emptyList(),
                    coachHome = "فينسنت كومباني",
                    coachAway = "لويس إنريكي"
                ),
                h2h = listOf(
                    H2HEntry("2023-03-08", "دوري أبطال أوروبا", "بايرن ميونخ", "باريس سان جيرمان", 2, 0),
                    H2HEntry("2023-02-14", "دوري أبطال أوروبا", "باريس سان جيرمان", "بايرن ميونخ", 0, 1),
                    H2HEntry("2021-04-13", "دوري أبطال أوروبا", "باريس سان جيرمان", "بايرن ميونخ", 0, 1)
                )
            ),

            // MATCH 5: Premier League Arsenal vs Chelsea
            Match(
                id = "m5",
                competitionId = "epl",
                round = "الجولة 31",
                homeTeam = ars,
                awayTeam = che,
                homeScore = 3,
                awayScore = 1,
                status = MatchStatus.FINISHED,
                liveMinute = "FT",
                matchDate = "YESTERDAY",
                matchTime = "19:30",
                stadium = "استاد الإمارات (لندن)",
                referee = "أنتوني تايلور",
                events = listOf(
                    MatchEvent("12'", EventType.GOAL, "بوكايو ساكا", "ars", "مارتن أوديغارد", "تسديدة مقوسة"),
                    MatchEvent("44'", EventType.GOAL, "كول بالمر", "che", null, "تسديدة رائعة من ضربة حرة"),
                    MatchEvent("63'", EventType.GOAL, "كاي هافيرتز", "ars", "ديكلان رايس", "رأسية من ركنية"),
                    MatchEvent("81'", EventType.GOAL, "لياندرو تروسارد", "ars", "غابرييل مارتينيلي", "تسديدة أرضية")
                ),
                stats = MatchStats(
                    possessionHome = 58, possessionAway = 42,
                    shotsHome = 16, shotsAway = 9,
                    shotsOnTargetHome = 7, shotsOnTargetAway = 3,
                    xGHome = 2.40f, xGAway = 0.95f,
                    cornersHome = 7, cornersAway = 3,
                    foulsHome = 10, foulsAway = 13,
                    offsidesHome = 2, offsidesAway = 2,
                    yellowCardsHome = 1, yellowCardsAway = 3,
                    redCardsHome = 0, redCardsAway = 0,
                    passesAccuracyHome = 88, passesAccuracyAway = 83
                ),
                lineup = MatchLineup(
                    formationHome = "4-3-3",
                    formationAway = "4-2-3-1",
                    startingHome = emptyList(),
                    startingAway = emptyList(),
                    benchHome = emptyList(),
                    benchAway = emptyList(),
                    coachHome = "ميكيل أرتيتا",
                    coachAway = "إنزو ماريسكا"
                ),
                h2h = listOf(
                    H2HEntry("2024-04-23", "الدوري الإنجليزي", "أرسنال", "تشيلسي", 5, 0),
                    H2HEntry("2023-10-21", "الدوري الإنجليزي", "تشيلسي", "أرسنال", 2, 2)
                )
            ),

            // MATCH 6: Serie A Derby della Madonnina Inter vs Milan
            Match(
                id = "m6",
                competitionId = "seriea",
                round = "الجولة 28",
                homeTeam = int,
                awayTeam = mil,
                homeScore = null,
                awayScore = null,
                status = MatchStatus.UPCOMING,
                liveMinute = "",
                matchDate = "TOMORROW",
                matchTime = "21:45",
                stadium = "استاد سان سيرو (ميلانو)",
                referee = "ماوريزيو مارياني",
                events = emptyList(),
                stats = MatchStats(50, 50, 0, 0, 0, 0, 0f, 0f, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                lineup = MatchLineup(
                    formationHome = "3-5-2",
                    formationAway = "4-2-3-1",
                    startingHome = emptyList(),
                    startingAway = emptyList(),
                    benchHome = emptyList(),
                    benchAway = emptyList(),
                    coachHome = "سيموني إنزاغي",
                    coachAway = "باولو فونسيكا"
                ),
                h2h = listOf(
                    H2HEntry("2024-09-22", "الدوري الإيطالي", "إنتر ميلان", "ميلان", 1, 2),
                    H2HEntry("2024-04-22", "الدوري الإيطالي", "ميلان", "إنتر ميلان", 1, 2)
                )
            ),

            // MATCH 7: Saudi Pro League Al-Ittihad vs Al-Hilal
            Match(
                id = "m7",
                competitionId = "roshn",
                round = "الجولة 27",
                homeTeam = itt,
                awayTeam = hil,
                homeScore = null,
                awayScore = null,
                status = MatchStatus.UPCOMING,
                liveMinute = "",
                matchDate = "TOMORROW",
                matchTime = "21:00",
                stadium = "مدينة الملك عبد الله الرياضية (الجوهرة)",
                referee = "سلافكو فينتشيتش",
                events = emptyList(),
                stats = MatchStats(50, 50, 0, 0, 0, 0, 0f, 0f, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                lineup = MatchLineup(
                    formationHome = "4-3-3",
                    formationAway = "4-2-3-1",
                    startingHome = emptyList(),
                    startingAway = emptyList(),
                    benchHome = emptyList(),
                    benchAway = emptyList(),
                    coachHome = "لوران بلان",
                    coachAway = "جورجي جيسوس"
                ),
                h2h = listOf(
                    H2HEntry("2024-09-21", "دوري روشن", "الهلال", "الاتحاد", 3, 1),
                    H2HEntry("2024-04-30", "كأس خادم الحرمين", "الاتحاد", "الهلال", 1, 2)
                )
            )
        )
    }

    // League Standings
    fun getStandings(competitionId: String): List<StandingEntry> {
        val rm = teams["rm"]!!
        val bar = teams["bar"]!!
        val atm = teams["atm"]!!
        val mci = teams["mci"]!!
        val liv = teams["liv"]!!
        val ars = teams["ars"]!!
        val che = teams["che"]!!
        val hil = teams["hil"]!!
        val nas = teams["nas"]!!
        val itt = teams["itt"]!!
        val int = teams["int"]!!
        val mil = teams["mil"]!!

        return when (competitionId) {
            "laliga" -> listOf(
                StandingEntry(1, rm, 28, 21, 5, 2, 64, 21, 68, listOf('W', 'W', 'W', 'D', 'W')),
                StandingEntry(2, bar, 28, 20, 4, 4, 68, 27, 64, listOf('W', 'W', 'D', 'W', 'L')),
                StandingEntry(3, atm, 28, 17, 7, 4, 48, 22, 58, listOf('W', 'D', 'W', 'W', 'D')),
                StandingEntry(4, Team("vil", "فياريال", "Villarreal", "VIL", 0xFFFFF000, 0xFF0038A8, "VIL", "إسبانيا"), 28, 15, 6, 7, 51, 38, 51, listOf('D', 'W', 'W', 'L', 'W')),
                StandingEntry(5, Team("ath", "أتلتيك بيلباو", "Athletic Club", "ATH", 0xFFEE2524, 0xFFFFFFFF, "ATH", "إسبانيا"), 28, 14, 8, 6, 43, 26, 50, listOf('W', 'D', 'D', 'W', 'W')),
                StandingEntry(6, Team("rso", "ريال سوسيداد", "Real Sociedad", "RSO", 0xFF00529F, 0xFFFFFFFF, "RSO", "إسبانيا"), 28, 12, 6, 10, 36, 30, 42, listOf('L', 'W', 'L', 'W', 'D'))
            )
            "epl" -> listOf(
                StandingEntry(1, liv, 30, 22, 5, 3, 69, 26, 71, listOf('W', 'W', 'W', 'D', 'L')),
                StandingEntry(2, ars, 30, 21, 6, 3, 67, 24, 69, listOf('W', 'W', 'W', 'W', 'W')),
                StandingEntry(3, mci, 30, 20, 6, 4, 65, 30, 66, listOf('W', 'D', 'W', 'W', 'W')),
                StandingEntry(4, che, 30, 15, 7, 8, 54, 38, 52, listOf('L', 'W', 'D', 'W', 'L')),
                StandingEntry(5, Team("new", "نيوكاسل يونايتد", "Newcastle", "NEW", 0xFF241F20, 0xFFFFFFFF, "NEW", "إنجلترا"), 30, 14, 8, 8, 50, 40, 50, listOf('W', 'L', 'W', 'D', 'W')),
                StandingEntry(6, Team("tot", "توتنهام هوتسبير", "Tottenham", "TOT", 0xFF132257, 0xFFFFFFFF, "TOT", "إنجلترا"), 30, 14, 5, 11, 55, 43, 47, listOf('L', 'L', 'W', 'W', 'D'))
            )
            "roshn" -> listOf(
                StandingEntry(1, hil, 25, 22, 3, 0, 74, 18, 69, listOf('W', 'W', 'W', 'W', 'D')),
                StandingEntry(2, itt, 25, 19, 3, 3, 58, 24, 60, listOf('W', 'W', 'W', 'L', 'W')),
                StandingEntry(3, nas, 25, 17, 5, 3, 61, 28, 56, listOf('W', 'D', 'W', 'W', 'D')),
                StandingEntry(4, Team("qad", "القادسية", "Al-Qadsiah", "QAD", 0xFF990000, 0xFFFFFFFF, "QAD", "السعودية"), 25, 15, 4, 6, 42, 26, 49, listOf('W', 'W', 'L', 'W', 'W')),
                StandingEntry(5, Team("shb", "الشباب", "Al-Shabab", "SHB", 0xFF000000, 0xFFFFFFFF, "SHB", "السعودية"), 25, 13, 5, 7, 39, 29, 44, listOf('D', 'W', 'L', 'W', 'L')),
                StandingEntry(6, Team("ahl", "الأهلي", "Al-Ahli", "AHL", 0xFF006838, 0xFFFFFFFF, "AHL", "السعودية"), 25, 12, 6, 7, 44, 31, 42, listOf('W', 'L', 'W', 'D', 'W'))
            )
            "ucl" -> listOf(
                StandingEntry(1, liv, 8, 7, 1, 0, 21, 5, 22, listOf('W', 'W', 'W', 'W', 'W')),
                StandingEntry(2, bar, 8, 6, 1, 1, 23, 10, 19, listOf('W', 'W', 'W', 'D', 'W')),
                StandingEntry(3, ars, 8, 6, 1, 1, 18, 4, 19, listOf('W', 'W', 'D', 'W', 'W')),
                StandingEntry(4, int, 8, 6, 1, 1, 14, 3, 19, listOf('W', 'W', 'W', 'L', 'W')),
                StandingEntry(5, rm, 8, 5, 1, 2, 19, 11, 16, listOf('W', 'L', 'W', 'W', 'L')),
                StandingEntry(6, mci, 8, 5, 1, 2, 18, 9, 16, listOf('D', 'W', 'L', 'W', 'W'))
            )
            else -> listOf(
                StandingEntry(1, int, 27, 20, 5, 2, 60, 19, 65, listOf('W', 'W', 'W', 'D', 'W')),
                StandingEntry(2, Team("nap", "نابولي", "Napoli", "NAP", 0xFF0080FF, 0xFFFFFFFF, "NAP", "إيطاليا"), 27, 19, 5, 3, 52, 21, 62, listOf('W', 'W', 'D', 'W', 'W')),
                StandingEntry(3, Team("ata", "أتالانتا", "Atalanta", "ATA", 0xFF0038A8, 0xFF000000, "ATA", "إيطاليا"), 27, 17, 5, 5, 58, 28, 56, listOf('W', 'L', 'W', 'W', 'W')),
                StandingEntry(4, mil, 27, 15, 6, 6, 49, 32, 51, listOf('L', 'W', 'W', 'D', 'W')),
                StandingEntry(5, Team("juv", "يوفنتوس", "Juventus", "JUV", 0xFF000000, 0xFFFFFFFF, "JUV", "إيطاليا"), 27, 13, 11, 3, 42, 22, 50, listOf('D', 'D', 'W', 'D', 'W'))
            )
        }
    }

    // Top Scorers
    fun getTopScorers(competitionId: String): List<TopScorer> {
        val rm = teams["rm"]!!
        val bar = teams["bar"]!!
        val mci = teams["mci"]!!
        val liv = teams["liv"]!!
        val hil = teams["hil"]!!
        val nas = teams["nas"]!!
        val bay = teams["bay"]!!

        return when (competitionId) {
            "laliga" -> listOf(
                TopScorer(1, "روبرت ليفاندوفسكي", bar, 23, 6, 4, 27),
                TopScorer(2, "كيليان مبابي", rm, 21, 4, 5, 26),
                TopScorer(3, "فينيسيوس جونيور", rm, 15, 9, 2, 24),
                TopScorer(4, "رافينيا", bar, 14, 11, 1, 26),
                TopScorer(5, "أنطوان غريزمان", teams["atm"]!!, 12, 7, 3, 27)
            )
            "epl" -> listOf(
                TopScorer(1, "إرلينغ هالاند", mci, 25, 3, 4, 28),
                TopScorer(2, "محمد صلاح", liv, 22, 13, 5, 29),
                TopScorer(3, "كول بالمر", teams["che"]!!, 17, 8, 6, 28),
                TopScorer(4, "بوكايو ساكا", teams["ars"]!!, 14, 12, 2, 27),
                TopScorer(5, "ألكسندر إيزاك", teams["mci"]!!, 13, 4, 1, 25)
            )
            "roshn" -> listOf(
                TopScorer(1, "كريستيانو رونالدو", nas, 26, 9, 7, 24),
                TopScorer(2, "ألكسندر ميتروفيتش", hil, 24, 5, 6, 23),
                TopScorer(3, "كريم بنزيما", teams["itt"]!!, 16, 7, 2, 22),
                TopScorer(4, "موسى بارو", teams["shb"]!!, 14, 4, 1, 24),
                TopScorer(5, "سالم الدوسري", hil, 13, 11, 2, 23)
            )
            else -> listOf(
                TopScorer(1, "هاري كين", bay, 10, 4, 2, 8),
                TopScorer(2, "إرلينغ هالاند", mci, 9, 2, 1, 7),
                TopScorer(3, "روبرت ليفاندوفسكي", bar, 9, 3, 2, 8),
                TopScorer(4, "فينيسيوس جونيور", rm, 8, 5, 1, 8),
                TopScorer(5, "كيليان مبابي", rm, 7, 3, 2, 8)
            )
        }
    }

    // Latest News
    val newsList = listOf(
        FootballNews(
            id = "n1",
            titleAr = "كلاسيكو الأرض يشتعل: ريال مدريد يتقدم وبرشلونة يقاتل في سانتياغو برنابيو",
            summaryAr = "مباراة ملحمية في العاصمة الإسبانية تشهد تألق فينيسيوس ومبابي في مواجهة ليفاندوفسكي ويامال، مع حضور جماهيري قياسي تجاوز 80 ألف متفرج.",
            category = "الدوري الإسباني",
            timeAgo = "منذ 15 دقيقة",
            readTime = "3 دقائق",
            hotTopic = true
        ),
        FootballNews(
            id = "n2",
            titleAr = "ديربي الرياض الكبير: رونالدو يسجل ثنائية تاريخية أمام متصدر الدوري الهلال",
            summaryAr = "المملكة أرينا تحتضن إحدى أقوى مباريات الموسم بين قطبي العاصمة، حيث أبدع الدوسري وميتروفيتش وقابلهم الدون بهدفين حاسمين.",
            category = "دوري روشن",
            timeAgo = "منذ 40 دقيقة",
            readTime = "2 دقيقة",
            hotTopic = true
        ),
        FootballNews(
            id = "n3",
            titleAr = "مانشستر سيتي يحسم قمة البريميرليغ أمام ليفربول بهدف قاتل لهالاند",
            summaryAr = "إثارة حتى الرمق الأخير على ملعب الاتحاد تبقي صراع الصدارة الإنجليزية مشتعلاً بين ثلاثي القمة ليفربول وأرسنال والسيتي.",
            category = "الدوري الإنجليزي",
            timeAgo = "منذ ساعتين",
            readTime = "4 دقائق",
            hotTopic = false
        ),
        FootballNews(
            id = "n4",
            titleAr = "قرعة نصف نهائي دوري أبطال أوروبا: صدام ناري مرتقب بين عمالقة القارة العجوز",
            summaryAr = "الاتحاد الأوروبي لكرة القدم يعلن عن مواعيد مباريات المربع الذهبي لأقوى بطولة أندية في العالم مع تطبيق تقنيات التسلل شبه الآلي الحديثة.",
            category = "دوري أبطال أوروبا",
            timeAgo = "منذ 4 ساعات",
            readTime = "2 دقيقة",
            hotTopic = false
        )
    )
}
