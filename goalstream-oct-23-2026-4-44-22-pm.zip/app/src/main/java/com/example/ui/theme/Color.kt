package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Pitch & Turf Greens
val PitchGreen = Color(0xFF00E676)
val PitchDarkGreen = Color(0xFF00C853)
val PitchEmerald = Color(0xFF10B981)
val PitchForest = Color(0xFF064E3B)

// Accent Trophy Gold
val TrophyGold = Color(0xFFFFB703)
val TrophyAmber = Color(0xFFF59E0B)

// Live Alert Red
val LiveRed = Color(0xFFEF4444)
val LiveRedDark = Color(0xFF991B1B)

// Cards & Accents
val YellowCard = Color(0xFFFFD600)
val RedCard = Color(0xFFFF1744)

// Neutral Dark Palette (Modern Dark Stadium Theme)
val DarkBackground = Color(0xFF0B1320)
val DarkSurface = Color(0xFF131F33)
val DarkSurfaceVariant = Color(0xFF1B2A45)
val DarkSurfaceBorder = Color(0xFF283A5A)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Light Palette
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightSurfaceBorder = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
