package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MatchStatus
import com.example.model.Team
import com.example.ui.theme.*

@Composable
fun TeamBadge(
    team: Team,
    size: Dp = 44.dp,
    modifier: Modifier = Modifier
) {
    val primary = Color(team.primaryColor)
    val secondary = Color(team.secondaryColor)

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.35f))
            .background(
                Brush.linearGradient(
                    colors = listOf(primary, secondary)
                )
            )
            .border(
                width = 1.5.dp,
                color = Color.White.copy(alpha = 0.3f),
                shape = RoundedCornerShape(size * 0.35f)
            ),
        contentAlignment = Alignment.Center
    ) {
        // High-contrast badge letters
        val textColor = if (team.id == "rm") Color(0xFF003366) else Color.White
        Text(
            text = team.initials,
            fontSize = (size.value * 0.36f).sp,
            fontWeight = FontWeight.Black,
            color = textColor,
            maxLines = 1
        )
    }
}

@Composable
fun LivePulsingBadge(
    minute: String,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Surface(
        modifier = modifier
            .testTag("live_status_badge")
            .clip(RoundedCornerShape(12.dp)),
        color = LiveRed.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, LiveRed.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(LiveRed.copy(alpha = alpha))
            )
            Text(
                text = "مباشر $minute",
                color = LiveRed,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun StatusBadge(
    status: MatchStatus,
    minute: String,
    time: String,
    modifier: Modifier = Modifier
) {
    when (status) {
        MatchStatus.LIVE -> LivePulsingBadge(minute = minute, modifier = modifier)
        MatchStatus.HALFTIME -> {
            Surface(
                modifier = modifier.clip(RoundedCornerShape(12.dp)),
                color = TrophyAmber.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TrophyAmber.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "بين الشوطين",
                    color = TrophyAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        MatchStatus.FINISHED -> {
            Surface(
                modifier = modifier.clip(RoundedCornerShape(12.dp)),
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
            ) {
                Text(
                    text = "انتهت FT",
                    color = DarkTextSecondary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        MatchStatus.UPCOMING -> {
            Surface(
                modifier = modifier.clip(RoundedCornerShape(12.dp)),
                color = PitchForest.copy(alpha = 0.4f),
                border = androidx.compose.foundation.BorderStroke(1.dp, PitchEmerald.copy(alpha = 0.4f))
            ) {
                Text(
                    text = time,
                    color = PitchGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}
