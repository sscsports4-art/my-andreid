package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.StatusBadge
import com.example.ui.components.TeamBadge
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchDetailScreen(
    match: Match,
    competitionName: String,
    flagEmoji: String,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("الأحداث ⚡", "الإحصائيات 📊", "التشكيلة 📋", "المواجهات ⚔️")

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("match_detail_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "$flagEmoji $competitionName",
                            style = MaterialTheme.typography.titleMedium,
                            color = TrophyGold
                        )
                        Text(
                            text = match.round,
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع",
                            tint = DarkTextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onFavoriteToggle,
                        modifier = Modifier.testTag("detail_fav_btn")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "المفضلة",
                            tint = if (isFavorite) TrophyGold else DarkTextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Match Hero Header
            item {
                MatchHeroHeader(match = match)
            }

            // Tabs Selector
            item {
                Spacer(modifier = Modifier.height(12.dp))
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurface,
                    contentColor = PitchGreen,
                    divider = {},
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            height = 3.dp,
                            color = PitchGreen
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp,
                                    color = if (selectedTab == index) PitchGreen else DarkTextSecondary
                                )
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Events / Timeline
                    if (match.events.isEmpty()) {
                        item {
                            EmptyStateView(
                                emoji = "⏳",
                                title = "لم تبدأ المباراة بعد أو لا توجد أحداث مسجلة",
                                subtitle = "ستظهر الأهداف والبطاقات والتبديلات لحظة بلحظة فور انطلاق صافرة البداية."
                            )
                        }
                    } else {
                        items(match.events.reversed()) { event ->
                            MatchEventRow(event = event, match = match)
                        }
                    }
                }
                1 -> {
                    // Statistics
                    item {
                        MatchStatsSection(stats = match.stats, match = match)
                    }
                }
                2 -> {
                    // Lineup & Pitch Visualizer
                    item {
                        MatchLineupSection(lineup = match.lineup, match = match)
                    }
                }
                3 -> {
                    // Head to Head
                    items(match.h2h) { encounter ->
                        H2HRow(encounter = encounter)
                    }
                }
            }
        }
    }
}

@Composable
fun MatchHeroHeader(match: Match) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(DarkSurfaceVariant.copy(alpha = 0.5f), DarkSurface)
                    )
                )
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Live / Status pill
            StatusBadge(
                status = match.status,
                minute = match.liveMinute,
                time = match.matchTime
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Teams & Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Home Team
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TeamBadge(team = match.homeTeam, size = 60.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = match.homeTeam.nameAr,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = match.homeTeam.country,
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted
                    )
                }

                // Middle Score Box
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (match.status == MatchStatus.UPCOMING) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PitchForest.copy(alpha = 0.3f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = match.matchTime,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = PitchGreen,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "${match.homeScore ?: 0}",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Black,
                                color = if (match.status == MatchStatus.LIVE) PitchGreen else DarkTextPrimary
                            )
                            Text(
                                text = ":",
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextMuted
                            )
                            Text(
                                text = "${match.awayScore ?: 0}",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Black,
                                color = if (match.status == MatchStatus.LIVE) PitchGreen else DarkTextPrimary
                            )
                        }
                    }
                }

                // Away Team
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TeamBadge(team = match.awayTeam, size = 60.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = match.awayTeam.nameAr,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = match.awayTeam.country,
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(10.dp))

            // Stadium & Referee details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Text(
                    text = "🏟️ ${match.stadium}",
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextSecondary
                )
                Text(
                    text = "🚩 الحكم: ${match.referee}",
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextSecondary
                )
            }
        }
    }
}

@Composable
fun MatchEventRow(event: MatchEvent, match: Match) {
    val isHome = event.teamId == match.homeTeam.id

    val iconText = when (event.type) {
        EventType.GOAL -> "⚽"
        EventType.PENALTY_GOAL -> "⚽ (ض.ج)"
        EventType.OWN_GOAL -> "⚽ (عكسي)"
        EventType.YELLOW_CARD -> "🟨"
        EventType.RED_CARD -> "🟥"
        EventType.SUBSTITUTION -> "🔄"
        EventType.VAR_DECISION -> "📺 VAR"
    }

    val eventColor = when (event.type) {
        EventType.GOAL, EventType.PENALTY_GOAL -> PitchGreen
        EventType.YELLOW_CARD -> YellowCard
        EventType.RED_CARD -> RedCard
        else -> TrophyGold
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isHome) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = iconText, fontSize = 16.sp)
                    Text(
                        text = event.player,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary
                    )
                }
                if (event.assistPlayer != null) {
                    Text(
                        text = "صناعة: ${event.assistPlayer}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DarkTextMuted
                    )
                }
                if (event.detail != null) {
                    Text(
                        text = event.detail,
                        style = MaterialTheme.typography.labelSmall,
                        color = eventColor
                    )
                }
            }
        } else {
            Spacer(modifier = Modifier.weight(1f))
        }

        // Center Minute Badge
        Box(
            modifier = Modifier
                .padding(horizontal = 8.dp)
                .clip(CircleShape)
                .background(DarkSurfaceVariant)
                .border(1.dp, eventColor.copy(alpha = 0.5f), CircleShape)
                .padding(horizontal = 10.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = event.minute,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary
            )
        }

        if (!isHome) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.End
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = event.player,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary,
                        textAlign = TextAlign.End
                    )
                    Text(text = iconText, fontSize = 16.sp)
                }
                if (event.assistPlayer != null) {
                    Text(
                        text = "صناعة: ${event.assistPlayer}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DarkTextMuted,
                        textAlign = TextAlign.End
                    )
                }
                if (event.detail != null) {
                    Text(
                        text = event.detail,
                        style = MaterialTheme.typography.labelSmall,
                        color = eventColor,
                        textAlign = TextAlign.End
                    )
                }
            }
        } else {
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun MatchStatsSection(stats: MatchStats, match: Match) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "الإحصائيات المباشرة والمقارنة",
                style = MaterialTheme.typography.titleMedium,
                color = TrophyGold,
                fontWeight = FontWeight.Bold
            )

            StatBarRow(
                title = "الاستحواذ %",
                homeVal = stats.possessionHome,
                awayVal = stats.possessionAway,
                homeDisplay = "${stats.possessionHome}%",
                awayDisplay = "${stats.possessionAway}%",
                homeColor = Color(match.homeTeam.primaryColor),
                awayColor = Color(match.awayTeam.primaryColor)
            )

            StatBarRow(
                title = "إجمالي التسديدات",
                homeVal = stats.shotsHome,
                awayVal = stats.shotsAway,
                homeDisplay = "${stats.shotsHome}",
                awayDisplay = "${stats.shotsAway}"
            )

            StatBarRow(
                title = "التسديدات على المرمى",
                homeVal = stats.shotsOnTargetHome,
                awayVal = stats.shotsOnTargetAway,
                homeDisplay = "${stats.shotsOnTargetHome}",
                awayDisplay = "${stats.shotsOnTargetAway}"
            )

            StatBarRow(
                title = "الأهداف المتوقعة (xG)",
                homeVal = (stats.xGHome * 10).toInt(),
                awayVal = (stats.xGAway * 10).toInt(),
                homeDisplay = "%.2f".format(stats.xGHome),
                awayDisplay = "%.2f".format(stats.xGAway)
            )

            StatBarRow(
                title = "الضربات الركنية",
                homeVal = stats.cornersHome,
                awayVal = stats.cornersAway,
                homeDisplay = "${stats.cornersHome}",
                awayDisplay = "${stats.cornersAway}"
            )

            StatBarRow(
                title = "الأخطاء المرتكبة",
                homeVal = stats.foulsHome,
                awayVal = stats.foulsAway,
                homeDisplay = "${stats.foulsHome}",
                awayDisplay = "${stats.foulsAway}"
            )

            StatBarRow(
                title = "دقة التمريرات %",
                homeVal = stats.passesAccuracyHome,
                awayVal = stats.passesAccuracyAway,
                homeDisplay = "${stats.passesAccuracyHome}%",
                awayDisplay = "${stats.passesAccuracyAway}%"
            )

            StatBarRow(
                title = "البطاقات الصفراء",
                homeVal = stats.yellowCardsHome,
                awayVal = stats.yellowCardsAway,
                homeDisplay = "${stats.yellowCardsHome}",
                awayDisplay = "${stats.yellowCardsAway}"
            )
        }
    }
}

@Composable
fun StatBarRow(
    title: String,
    homeVal: Int,
    awayVal: Int,
    homeDisplay: String,
    awayDisplay: String,
    homeColor: Color = PitchGreen,
    awayColor: Color = TrophyAmber
) {
    val total = (homeVal + awayVal).coerceAtLeast(1)
    val homeRatio = homeVal.toFloat() / total.toFloat()
    val animatedRatio by animateFloatAsState(
        targetValue = homeRatio,
        animationSpec = tween(600),
        label = "statBar"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = homeDisplay,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = DarkTextSecondary
            )
            Text(
                text = awayDisplay,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Segmented Dual Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(DarkSurfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .weight(animatedRatio.coerceIn(0.05f, 0.95f))
                    .fillMaxHeight()
                    .background(homeColor)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Box(
                modifier = Modifier
                    .weight((1f - animatedRatio).coerceIn(0.05f, 0.95f))
                    .fillMaxHeight()
                    .background(awayColor)
            )
        }
    }
}

@Composable
fun MatchLineupSection(lineup: MatchLineup, match: Match) {
    var showHomeTeam by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Selector Home / Away
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurfaceVariant)
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (showHomeTeam) PitchGreen else Color.Transparent)
                    .clickable { showHomeTeam = true }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${match.homeTeam.nameAr} (${lineup.formationHome})",
                    color = if (showHomeTeam) Color.Black else DarkTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (!showHomeTeam) PitchGreen else Color.Transparent)
                    .clickable { showHomeTeam = false }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${match.awayTeam.nameAr} (${lineup.formationAway})",
                    color = if (!showHomeTeam) Color.Black else DarkTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tactical Football Pitch Visualizer
        TacticalPitchCanvas(
            players = if (showHomeTeam) lineup.startingHome else lineup.startingAway,
            formation = if (showHomeTeam) lineup.formationHome else lineup.formationAway,
            teamColor = if (showHomeTeam) Color(match.homeTeam.primaryColor) else Color(match.awayTeam.primaryColor)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Coach info
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "👔 المدير الفني: ${if (showHomeTeam) lineup.coachHome else lineup.coachAway}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = "الخطة: ${if (showHomeTeam) lineup.formationHome else lineup.formationAway}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TrophyGold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Starting Players List with Ratings
        Text(
            text = "التشكيلة الأساسية والتقييمات",
            style = MaterialTheme.typography.titleMedium,
            color = TrophyGold,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 6.dp)
        )

        val activeList = if (showHomeTeam) lineup.startingHome else lineup.startingAway
        if (activeList.isEmpty()) {
            Text(
                text = "سيتم الإعلان عن التشكيلة الرسمية قبل انطلاق المباراة بساعة.",
                style = MaterialTheme.typography.bodyMedium,
                color = DarkTextMuted,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else {
            activeList.forEach { player ->
                PlayerListTile(player = player)
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun TacticalPitchCanvas(
    players: List<PlayerLineup>,
    formation: String,
    teamColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1B4332))
            .border(2.dp, PitchGreen.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        // Turf Lines Drawing
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val lineColor = Color.White.copy(alpha = 0.35f)
            val stroke = Stroke(width = 2.dp.toPx())

            // Lawn stripes
            val stripeCount = 6
            val stripeHeight = h / stripeCount
            for (i in 0 until stripeCount) {
                if (i % 2 == 0) {
                    drawRect(
                        color = Color(0xFF2D6A4F).copy(alpha = 0.4f),
                        topLeft = Offset(0f, i * stripeHeight),
                        size = Size(w, stripeHeight)
                    )
                }
            }

            // Outer pitch bounds
            drawRoundRect(
                color = lineColor,
                topLeft = Offset(12.dp.toPx(), 12.dp.toPx()),
                size = Size(w - 24.dp.toPx(), h - 24.dp.toPx()),
                cornerRadius = CornerRadius(8.dp.toPx()),
                style = stroke
            )

            // Halfway Line
            drawLine(
                color = lineColor,
                start = Offset(12.dp.toPx(), h / 2),
                end = Offset(w - 12.dp.toPx(), h / 2),
                strokeWidth = 2.dp.toPx()
            )

            // Center Circle
            drawCircle(
                color = lineColor,
                radius = 36.dp.toPx(),
                center = Offset(w / 2, h / 2),
                style = stroke
            )

            // Center Spot
            drawCircle(
                color = lineColor,
                radius = 3.dp.toPx(),
                center = Offset(w / 2, h / 2)
            )

            // Top Penalty Box
            drawRect(
                color = lineColor,
                topLeft = Offset(w * 0.25f, 12.dp.toPx()),
                size = Size(w * 0.5f, 50.dp.toPx()),
                style = stroke
            )

            // Bottom Penalty Box
            drawRect(
                color = lineColor,
                topLeft = Offset(w * 0.25f, h - 12.dp.toPx() - 50.dp.toPx()),
                size = Size(w * 0.5f, 50.dp.toPx()),
                style = stroke
            )
        }

        // Overlay Player Tokens
        if (players.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // GK (bottom or top)
                val gk = players.firstOrNull { it.position == "GK" } ?: players.first()
                val defenders = players.filter { it.position == "DF" }
                val midfielders = players.filter { it.position == "MF" }
                val forwards = players.filter { it.position == "FW" }

                // Forwards row
                if (forwards.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        forwards.forEach { p -> PlayerPitchNode(player = p, teamColor = teamColor) }
                    }
                }

                // Midfielders row
                if (midfielders.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        midfielders.forEach { p -> PlayerPitchNode(player = p, teamColor = teamColor) }
                    }
                }

                // Defenders row
                if (defenders.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        defenders.forEach { p -> PlayerPitchNode(player = p, teamColor = teamColor) }
                    }
                }

                // Goalkeeper row
                PlayerPitchNode(player = gk, teamColor = TrophyGold)
            }
        }
    }
}

@Composable
fun PlayerPitchNode(player: PlayerLineup, teamColor: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(teamColor)
                .border(1.5.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "${player.number}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (teamColor == Color.White) Color.Black else Color.White
            )
        }

        Text(
            text = player.nameAr.split(" ").lastOrNull() ?: player.nameAr,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1
        )
    }
}

@Composable
fun PlayerListTile(player: PlayerLineup) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${player.number}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = DarkTextPrimary
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = player.nameAr,
                            style = MaterialTheme.typography.titleMedium,
                            color = DarkTextPrimary
                        )
                        if (player.isCaptain) {
                            Text(
                                text = "©",
                                color = TrophyGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                        if (player.goalsScored > 0) {
                            Text(
                                text = "⚽".repeat(player.goalsScored),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Text(
                        text = player.position,
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted
                    )
                }
            }

            // Rating Pill
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (player.rating >= 8.0f) PitchForest else DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (player.rating >= 8.0f) PitchGreen else DarkSurfaceBorder
                )
            ) {
                Text(
                    text = "%.1f".format(player.rating),
                    color = if (player.rating >= 8.0f) PitchGreen else DarkTextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
fun H2HRow(encounter: H2HEntry) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = encounter.competition,
                    style = MaterialTheme.typography.labelSmall,
                    color = TrophyGold
                )
                Text(
                    text = encounter.date,
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextMuted
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = encounter.homeTeamName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextPrimary
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
                ) {
                    Text(
                        text = "${encounter.homeScore} - ${encounter.awayScore}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = DarkTextPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
                Text(
                    text = encounter.awayTeamName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextPrimary
                )
            }
        }
    }
}

@Composable
fun EmptyStateView(emoji: String, title: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = emoji, fontSize = 42.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = DarkTextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}
