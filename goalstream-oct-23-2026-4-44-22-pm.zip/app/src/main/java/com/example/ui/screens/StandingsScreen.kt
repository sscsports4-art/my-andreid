package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Competition
import com.example.model.StandingEntry
import com.example.model.TopScorer
import com.example.ui.components.TeamBadge
import com.example.ui.theme.*

@Composable
fun StandingsScreen(
    competitions: List<Competition>,
    selectedCompetitionId: String,
    onSelectCompetition: (String) -> Unit,
    subTab: Int,
    onSelectSubTab: (Int) -> Unit,
    standings: List<StandingEntry>,
    topScorers: List<TopScorer>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("standings_screen")
    ) {
        // Competition horizontal pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            competitions.forEach { comp ->
                val isSelected = comp.id == selectedCompetitionId
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectCompetition(comp.id) },
                    label = {
                        Text(
                            text = "${comp.flag} ${comp.nameAr}",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PitchGreen,
                        selectedLabelColor = Color(0xFF022C1A),
                        containerColor = DarkSurface,
                        labelColor = DarkTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = DarkSurfaceBorder,
                        selectedBorderColor = PitchGreen
                    )
                )
            }
        }

        // Sub-tabs: Table vs Scorers
        TabRow(
            selectedTabIndex = subTab,
            containerColor = DarkSurface,
            contentColor = PitchGreen,
            divider = {},
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[subTab]),
                    height = 3.dp,
                    color = PitchGreen
                )
            }
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { onSelectSubTab(0) },
                text = {
                    Text(
                        text = "جدول الترتيب 🏆",
                        fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Normal,
                        color = if (subTab == 0) PitchGreen else DarkTextSecondary
                    )
                }
            )
            Tab(
                selected = subTab == 1,
                onClick = { onSelectSubTab(1) },
                text = {
                    Text(
                        text = "قائمة الهدافين ⚽",
                        fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Normal,
                        color = if (subTab == 1) PitchGreen else DarkTextSecondary
                    )
                }
            )
        }

        if (subTab == 0) {
            // Standings Table Header
            Surface(
                color = DarkSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "#",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        modifier = Modifier.width(26.dp)
                    )
                    Text(
                        text = "الفريق",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "لعب",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(32.dp)
                    )
                    Text(
                        text = "ف",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(28.dp)
                    )
                    Text(
                        text = "ت",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(28.dp)
                    )
                    Text(
                        text = "خ",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(28.dp)
                    )
                    Text(
                        text = "الفارق",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(36.dp)
                    )
                    Text(
                        text = "النقاط",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = TrophyGold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(38.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(standings) { row ->
                    StandingRowItem(row = row)
                    HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.4f))
                }

                // Table Legend Footer
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00E5FF))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المراكز المؤهلة لدوري أبطال أوروبا (1 - 4)",
                                style = MaterialTheme.typography.labelSmall,
                                color = DarkTextSecondary
                            )
                        }
                    }
                }
            }
        } else {
            // Top Scorers List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(topScorers) { scorer ->
                    TopScorerCard(scorer = scorer)
                }
            }
        }
    }
}

@Composable
fun StandingRowItem(row: StandingEntry) {
    val rankColor = when (row.rank) {
        in 1..4 -> Color(0xFF00E5FF)
        5, 6 -> TrophyGold
        else -> DarkTextMuted
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Rank with colored indicator bar
        Row(
            modifier = Modifier.width(26.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(18.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(rankColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "${row.rank}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = if (row.rank <= 4) DarkTextPrimary else DarkTextSecondary
            )
        }

        // Team Logo + Name
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TeamBadge(team = row.team, size = 28.dp)
            Text(
                text = row.team.nameAr,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = DarkTextPrimary,
                maxLines = 1
            )
        }

        // P, W, D, L
        Text(
            text = "${row.played}",
            style = MaterialTheme.typography.bodyMedium,
            color = DarkTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(32.dp)
        )
        Text(
            text = "${row.won}",
            style = MaterialTheme.typography.bodyMedium,
            color = DarkTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(28.dp)
        )
        Text(
            text = "${row.drawn}",
            style = MaterialTheme.typography.bodyMedium,
            color = DarkTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(28.dp)
        )
        Text(
            text = "${row.lost}",
            style = MaterialTheme.typography.bodyMedium,
            color = DarkTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(28.dp)
        )

        // Goal Diff
        val gdSign = if (row.goalDifference > 0) "+${row.goalDifference}" else "${row.goalDifference}"
        Text(
            text = gdSign,
            style = MaterialTheme.typography.bodyMedium,
            color = if (row.goalDifference > 0) PitchGreen else DarkTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(36.dp)
        )

        // Points
        Text(
            text = "${row.points}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = PitchGreen,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(38.dp)
        )
    }
}

@Composable
fun TopScorerCard(scorer: TopScorer) {
    val medal = when (scorer.rank) {
        1 -> "🥇"
        2 -> "🥈"
        3 -> "🥉"
        else -> "${scorer.rank}"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = medal,
                    fontSize = if (scorer.rank <= 3) 22.sp else 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TrophyGold,
                    modifier = Modifier.width(30.dp),
                    textAlign = TextAlign.Center
                )

                TeamBadge(team = scorer.team, size = 42.dp)

                Column {
                    Text(
                        text = scorer.playerName,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "${scorer.team.nameAr} • ${scorer.matches} مباراة",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted
                    )
                }
            }

            // Goals Counter Badge
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PitchForest,
                border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "⚽", fontSize = 14.sp)
                    Text(
                        text = "${scorer.goals}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = PitchGreen
                    )
                    if (scorer.assists > 0) {
                        Text(
                            text = "(+${scorer.assists} صناعة)",
                            fontSize = 11.sp,
                            color = TrophyGold
                        )
                    }
                }
            }
        }
    }
}
