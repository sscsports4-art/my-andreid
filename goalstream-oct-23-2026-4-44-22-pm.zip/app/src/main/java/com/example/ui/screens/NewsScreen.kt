package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.FootballNews
import com.example.ui.theme.*

@Composable
fun NewsScreen(
    newsList: List<FootballNews>,
    modifier: Modifier = Modifier
) {
    var selectedNews by remember { mutableStateOf<FootballNews?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("news_screen")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "آخر الأخبار والتقارير العالمية 📰",
                    style = MaterialTheme.typography.titleLarge,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            items(newsList) { item ->
                NewsCard(item = item, onClick = { selectedNews = item })
            }
        }
    }

    // Full Story Dialog
    selectedNews?.let { news ->
        Dialog(onDismissRequest = { selectedNews = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PitchForest,
                            border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = news.category,
                                color = PitchGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        IconButton(onClick = { selectedNews = null }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = DarkTextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = news.titleAr,
                        style = MaterialTheme.typography.titleLarge,
                        color = DarkTextPrimary,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⏱️ ${news.timeAgo}",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                        Text(
                            text = "• قراءة في ${news.readTime}",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = DarkSurfaceBorder)
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = news.summaryAr,
                        style = MaterialTheme.typography.bodyLarge,
                        color = DarkTextSecondary,
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { selectedNews = null },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("close_news_dialog"),
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "تمت القراءة",
                            color = Color(0xFF022C1A),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NewsCard(
    item: FootballNews,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (item.hotTopic) LiveRed.copy(alpha = 0.4f) else DarkSurfaceBorder,
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (item.hotTopic) LiveRed.copy(alpha = 0.15f) else DarkSurfaceVariant
                    ) {
                        Text(
                            text = if (item.hotTopic) "عاجل 🔥" else item.category,
                            color = if (item.hotTopic) LiveRed else TrophyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (item.hotTopic) {
                        Text(
                            text = item.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                    }
                }

                Text(
                    text = item.timeAgo,
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextMuted
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = item.titleAr,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = item.summaryAr,
                style = MaterialTheme.typography.bodyMedium,
                color = DarkTextSecondary,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📖 قراءة كاملة (${item.readTime})",
                    style = MaterialTheme.typography.labelSmall,
                    color = PitchGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
