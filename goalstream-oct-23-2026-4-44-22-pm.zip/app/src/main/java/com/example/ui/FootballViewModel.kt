package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FootballRepository
import com.example.model.Competition
import com.example.model.Match
import com.example.model.MatchStatus
import com.example.model.StandingEntry
import com.example.model.TopScorer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class DateFilter(val labelAr: String, val code: String) {
    YESTERDAY("أمس", "YESTERDAY"),
    TODAY("اليوم (مباشر)", "TODAY"),
    TOMORROW("غداً", "TOMORROW")
}

enum class StatusFilter(val labelAr: String) {
    ALL("الكل"),
    LIVE("مباشر الآن 🔴"),
    FINISHED("المنتهية"),
    UPCOMING("القادمة"),
    FAVORITES("المفضلة ⭐")
}

data class GoalAlert(
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class FilterData(
    val date: DateFilter,
    val status: StatusFilter,
    val compId: String?,
    val query: String,
    val favs: Set<String>
)

class FootballViewModel(
    private val repository: FootballRepository = FootballRepository()
) : ViewModel() {

    val competitions: List<Competition> = repository.competitions
    val newsList = repository.newsList

    private val _selectedBottomTab = MutableStateFlow(0)
    val selectedBottomTab: StateFlow<Int> = _selectedBottomTab.asStateFlow()

    private val _selectedDateFilter = MutableStateFlow(DateFilter.TODAY)
    val selectedDateFilter: StateFlow<DateFilter> = _selectedDateFilter.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow(StatusFilter.ALL)
    val selectedStatusFilter: StateFlow<StatusFilter> = _selectedStatusFilter.asStateFlow()

    private val _selectedCompetitionFilter = MutableStateFlow<String?>(null)
    val selectedCompetitionFilter: StateFlow<String?> = _selectedCompetitionFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedMatch = MutableStateFlow<Match?>(null)
    val selectedMatch: StateFlow<Match?> = _selectedMatch.asStateFlow()

    private val _selectedStandingsCompetition = MutableStateFlow("laliga")
    val selectedStandingsCompetition: StateFlow<String> = _selectedStandingsCompetition.asStateFlow()

    private val _standingsSubTab = MutableStateFlow(0) // 0: Table, 1: Scorers
    val standingsSubTab: StateFlow<Int> = _standingsSubTab.asStateFlow()

    private val _goalAlert = MutableStateFlow<GoalAlert?>(null)
    val goalAlert: StateFlow<GoalAlert?> = _goalAlert.asStateFlow()

    private val _isLiveSimulationActive = MutableStateFlow(true)
    val isLiveSimulationActive: StateFlow<Boolean> = _isLiveSimulationActive.asStateFlow()

    val favoriteMatchIds: StateFlow<Set<String>> = repository.favoriteMatchIds

    private var simulationJob: Job? = null

    init {
        startSimulationLoop()
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            while (true) {
                delay(6000)
                if (_isLiveSimulationActive.value) {
                    repository.simulateLiveTick()
                    val currentSelected = _selectedMatch.value
                    if (currentSelected != null) {
                        val updated = repository.matches.value.find { it.id == currentSelected.id }
                        if (updated != null) {
                            _selectedMatch.value = updated
                        }
                    }
                }
            }
        }
    }

    fun selectBottomTab(tab: Int) {
        _selectedBottomTab.value = tab
    }

    fun selectDateFilter(filter: DateFilter) {
        _selectedDateFilter.value = filter
    }

    fun selectStatusFilter(filter: StatusFilter) {
        _selectedStatusFilter.value = filter
    }

    fun selectCompetitionFilter(compId: String?) {
        _selectedCompetitionFilter.value = if (_selectedCompetitionFilter.value == compId) null else compId
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openMatchDetails(match: Match) {
        _selectedMatch.value = match
    }

    fun closeMatchDetails() {
        _selectedMatch.value = null
    }

    fun selectStandingsCompetition(compId: String) {
        _selectedStandingsCompetition.value = compId
    }

    fun setStandingsSubTab(tab: Int) {
        _standingsSubTab.value = tab
    }

    fun toggleFavorite(matchId: String) {
        repository.toggleFavorite(matchId)
    }

    fun toggleLiveSimulation() {
        _isLiveSimulationActive.value = !_isLiveSimulationActive.value
    }

    fun triggerSimulatedGoal() {
        repository.simulateLiveTick()
        val m1 = repository.matches.value.find { it.id == "m1" }
        if (m1 != null) {
            _goalAlert.value = GoalAlert(
                title = "⚽ جوووول في البرنابيو!",
                message = "هدف مثير لصالح برشلونة بقدم لامين يامال (النتيجة: 2 - 2)"
            )
            if (_selectedMatch.value?.id == "m1") {
                _selectedMatch.value = m1
            }
        }
    }

    fun dismissGoalAlert() {
        _goalAlert.value = null
    }

    private val filtersFlow = combine(
        _selectedDateFilter,
        _selectedStatusFilter,
        _selectedCompetitionFilter,
        _searchQuery,
        repository.favoriteMatchIds
    ) { date, status, comp, query, favs ->
        FilterData(date, status, comp, query, favs)
    }

    val filteredMatches: StateFlow<List<Match>> = combine(
        repository.matches,
        filtersFlow
    ) { allMatches: List<Match>, filter: FilterData ->
        allMatches.filter { match ->
            val matchesDate = match.matchDate == filter.date.code
            val matchesStatus = when (filter.status) {
                StatusFilter.ALL -> true
                StatusFilter.LIVE -> match.status == MatchStatus.LIVE
                StatusFilter.FINISHED -> match.status == MatchStatus.FINISHED
                StatusFilter.UPCOMING -> match.status == MatchStatus.UPCOMING
                StatusFilter.FAVORITES -> filter.favs.contains(match.id)
            }
            val matchesComp = filter.compId == null || match.competitionId == filter.compId
            val matchesSearch = filter.query.isBlank() ||
                    match.homeTeam.nameAr.contains(filter.query, ignoreCase = true) ||
                    match.awayTeam.nameAr.contains(filter.query, ignoreCase = true) ||
                    match.homeTeam.nameEn.contains(filter.query, ignoreCase = true) ||
                    match.awayTeam.nameEn.contains(filter.query, ignoreCase = true) ||
                    match.stadium.contains(filter.query, ignoreCase = true)

            matchesDate && matchesStatus && matchesComp && matchesSearch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getStandings(competitionId: String): List<StandingEntry> =
        repository.getStandings(competitionId)

    fun getTopScorers(competitionId: String): List<TopScorer> =
        repository.getTopScorers(competitionId)
}
