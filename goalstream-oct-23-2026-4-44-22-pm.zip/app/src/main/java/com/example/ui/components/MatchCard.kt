package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EventType
import com.example.model.Match
import com.example.model.MatchStatus
import com.example.ui.theme.*

@Composable
fun MatchCard(
    match: Match,
    competitionName: String,
    flagEmoji: String,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isLive = match.status == MatchStatus.LIVE

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("match_card_${match.id}")
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isLive) 1.5.dp else 1.dp,
                brush = if (isLive) Brush.horizontalGradient(
                    listOf(LiveRed.copy(alpha = 0.6f), PitchGreen.copy(alpha = 0.6f))
                ) else Brush.linearGradient(
                    listOf(DarkSurfaceBorder, DarkSurfaceBorder.copy(alpha = 0.3f))
                ),
                shape = RoundedCornerShape(18.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = DarkSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Competition & Round + Favorite Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = flagEmoji, fontSize = 14.sp)
                    Text(
                        text = competitionName,
                        style = MaterialTheme.typography.labelSmall,
                        color = TrophyGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• ${match.round}",
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextMuted
                    )
                }

                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("favorite_btn_${match.id}")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) TrophyGold else DarkTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Main Score Area: Home Team vs Away Team
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Home Team
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TeamBadge(team = match.homeTeam, size = 48.dp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = match.homeTeam.nameAr,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }

                // Middle: Score & Match Status
                Column(
                    modifier = Modifier.padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    StatusBadge(
                        status = match.status,
                        minute = match.liveMinute,
                        time = match.matchTime
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    if (match.status == MatchStatus.UPCOMING) {
                        Text(
                            text = "VS",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = DarkTextSecondary
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "${match.homeScore ?: 0}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isLive) PitchGreen else DarkTextPrimary
                            )
                            Text(
                                text = "-",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextMuted
                            )
                            Text(
                                text = "${match.awayScore ?: 0}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isLive) PitchGreen else DarkTextPrimary
                            )
                        }
                    }
                }

                // Away Team
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TeamBadge(team = match.awayTeam, size = 48.dp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = match.awayTeam.nameAr,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Scorers snippet if available
            val goalEvents = match.events.filter { it.type == EventType.GOAL || it.type == EventType.PENALTY_GOAL }
            if (goalEvents.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(text = "⚽", fontSize = 12.sp, modifier = Modifier.padding(end = 4.dp))
                    val scorersSummary = goalEvents.take(3).joinToString(" • ") { "${it.player} ${it.minute}" }
                    Text(
                        text = scorersSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DarkTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Stadium Footer
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🏟️ ${match.stadium}",
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "عرض التفاصيل ❯",
                    style = MaterialTheme.typography.labelSmall,
                    color = PitchGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
