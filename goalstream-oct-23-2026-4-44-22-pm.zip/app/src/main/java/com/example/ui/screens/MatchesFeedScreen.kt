package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Competition
import com.example.model.Match
import com.example.ui.DateFilter
import com.example.ui.GoalAlert
import com.example.ui.StatusFilter
import com.example.ui.components.MatchCard
import com.example.ui.theme.*

@Composable
fun MatchesFeedScreen(
    matches: List<Match>,
    competitions: List<Competition>,
    favoriteIds: Set<String>,
    selectedDate: DateFilter,
    onSelectDate: (DateFilter) -> Unit,
    selectedStatus: StatusFilter,
    onSelectStatus: (StatusFilter) -> Unit,
    selectedCompetitionId: String?,
    onSelectCompetition: (String?) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    goalAlert: GoalAlert?,
    onDismissGoalAlert: () -> Unit,
    isLiveSimActive: Boolean,
    onToggleLiveSim: () -> Unit,
    onSimulateGoal: () -> Unit,
    onSelectMatch: (Match) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val compMap = remember(competitions) { competitions.associateBy { it.id } }
    var isSearchExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("matches_feed_screen")
    ) {
        // App Header: Modern Stadium Brand Bar
        Surface(
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(PitchGreen, TrophyGold)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "⚽", fontSize = 18.sp)
                        }

                        Column {
                            Text(
                                text = "كورة لايف | Kooora",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = DarkTextPrimary
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isLiveSimActive) PitchGreen else DarkTextMuted)
                                )
                                Text(
                                    text = if (isLiveSimActive) "البث المباشر نشط" else "متوقف مؤقتاً",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isLiveSimActive) PitchGreen else DarkTextMuted
                                )
                            }
                        }
                    }

                    // Action buttons: Search & Goal Simulation
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Quick Simulate Goal trigger
                        Button(
                            onClick = onSimulateGoal,
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("sim_goal_button"),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LiveRed.copy(alpha = 0.2f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, LiveRed.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "⚡ هدف مباشر",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = LiveRed
                            )
                        }

                        IconButton(
                            onClick = { isSearchExpanded = !isSearchExpanded },
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("search_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isSearchExpanded) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = DarkTextPrimary
                            )
                        }
                    }
                }

                // Search field (expandable)
                AnimatedVisibility(
                    visible = isSearchExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .testTag("search_input"),
                        placeholder = {
                            Text(
                                "ابحث عن فريق (ريال مدريد، ليفربول...) أو ملعب",
                                color = DarkTextMuted,
                                fontSize = 12.sp
                            )
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PitchGreen,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = DarkTextPrimary,
                            unfocusedTextColor = DarkTextPrimary,
                            cursorColor = PitchGreen
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Live Goal Banner (Animated Snack)
        AnimatedVisibility(
            visible = goalAlert != null,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            goalAlert?.let { alert ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("live_goal_banner"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1428)),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, LiveRed)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(text = "🔥", fontSize = 24.sp)
                            Column {
                                Text(
                                    text = alert.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = LiveRed
                                )
                                Text(
                                    text = alert.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = DarkTextPrimary
                                )
                            }
                        }

                        IconButton(onClick = onDismissGoalAlert) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = DarkTextMuted
                            )
                        }
                    }
                }
            }
        }

        // Date Selector Bar (Yesterday, Today, Tomorrow)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurfaceVariant)
                .padding(4.dp)
        ) {
            DateFilter.values().forEach { filter ->
                val isSelected = filter == selectedDate
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) PitchGreen else Color.Transparent)
                        .clickable { onSelectDate(filter) }
                        .padding(vertical = 8.dp)
                        .testTag("date_tab_${filter.code}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = filter.labelAr,
                        color = if (isSelected) Color(0xFF022C1A) else DarkTextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Status Filter Chips Row (All, Live, Finished, Upcoming, Favorites)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusFilter.values().forEach { status ->
                val isSelected = status == selectedStatus
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectStatus(status) },
                    label = {
                        Text(
                            text = status.labelAr,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = if (status == StatusFilter.LIVE) LiveRed.copy(alpha = 0.25f) else PitchGreen,
                        selectedLabelColor = if (status == StatusFilter.LIVE) LiveRed else Color(0xFF022C1A),
                        containerColor = DarkSurface,
                        labelColor = DarkTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = DarkSurfaceBorder,
                        selectedBorderColor = if (status == StatusFilter.LIVE) LiveRed else PitchGreen
                    )
                )
            }
        }

        // Competition Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // "All Leagues" Chip
            val isAllSelected = selectedCompetitionId == null
            FilterChip(
                selected = isAllSelected,
                onClick = { onSelectCompetition(null) },
                label = { Text("كل البطولات 🌐", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = TrophyGold,
                    selectedLabelColor = Color.Black,
                    containerColor = DarkSurface,
                    labelColor = DarkTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isAllSelected,
                    borderColor = DarkSurfaceBorder,
                    selectedBorderColor = TrophyGold
                )
            )

            competitions.forEach { comp ->
                val isCompSelected = comp.id == selectedCompetitionId
                FilterChip(
                    selected = isCompSelected,
                    onClick = { onSelectCompetition(comp.id) },
                    label = { Text("${comp.flag} ${comp.nameAr}", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TrophyGold,
                        selectedLabelColor = Color.Black,
                        containerColor = DarkSurface,
                        labelColor = DarkTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isCompSelected,
                        borderColor = DarkSurfaceBorder,
                        selectedBorderColor = TrophyGold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Match list
        if (matches.isEmpty()) {
            EmptyStateView(
                emoji = "⚽",
                title = "لا توجد مباريات مطابقة للبحث أو الفلتر",
                subtitle = "جرب تغيير تاريخ العرض أو اختيار 'الكل' للاطلاع على مواعيد ونتائج البطولات الأخرى."
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(matches, key = { it.id }) { match ->
                    val comp = compMap[match.competitionId]
                    MatchCard(
                        match = match,
                        competitionName = comp?.nameAr ?: "",
                        flagEmoji = comp?.flag ?: "⚽",
                        isFavorite = favoriteIds.contains(match.id),
                        onFavoriteClick = { onToggleFavorite(match.id) },
                        onClick = { onSelectMatch(match) }
                    )
                }
            }
        }
    }
}
