package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Competition
import com.example.model.Match
import com.example.ui.components.MatchCard
import com.example.ui.theme.*

@Composable
fun FavoritesScreen(
    matches: List<Match>,
    favoriteIds: Set<String>,
    competitions: List<Competition>,
    onToggleFavorite: (String) -> Unit,
    onSelectMatch: (Match) -> Unit,
    onExploreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var notificationsEnabled by remember { mutableStateOf(true) }
    val compMap = remember(competitions) { competitions.associateBy { it.id } }
    val favoriteMatches = remember(matches, favoriteIds) {
        matches.filter { favoriteIds.contains(it.id) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("favorites_screen")
    ) {
        // Notification Toggle Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TrophyGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = TrophyGold
                        )
                    }

                    Column {
                        Text(
                            text = "تنبيهات الأهداف الفورية 🔔",
                            style = MaterialTheme.typography.titleMedium,
                            color = DarkTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "إشعار اهتزاز وصوت عند تسجيل الأهداف",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                    }
                }

                Switch(
                    checked = notificationsEnabled,
                    onCheckedChange = { notificationsEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF022C1A),
                        checkedTrackColor = PitchGreen
                    )
                )
            }
        }

        if (favoriteMatches.isEmpty()) {
            EmptyStateView(
                emoji = "⭐",
                title = "لا توجد مباريات مفضلة حتى الآن",
                subtitle = "اضغط على أيقونة النجمة ⭐ بجانب أي مباراة لإضافتها إلى قائمتك وتلقي تنبيهاتها المباشرة."
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onExploreClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp)
                    .testTag("explore_matches_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = PitchGreen),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "استكشاف مباريات اليوم ⚽",
                    color = Color(0xFF022C1A),
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "مبارياتك المفضلة (${favoriteMatches.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TrophyGold
                    )
                }

                items(favoriteMatches) { match ->
                    val comp = compMap[match.competitionId]
                    MatchCard(
                        match = match,
                        competitionName = comp?.nameAr ?: "",
                        flagEmoji = comp?.flag ?: "⚽",
                        isFavorite = true,
                        onFavoriteClick = { onToggleFavorite(match.id) },
                        onClick = { onSelectMatch(match) }
                    )
                }
            }
        }
    }
}
