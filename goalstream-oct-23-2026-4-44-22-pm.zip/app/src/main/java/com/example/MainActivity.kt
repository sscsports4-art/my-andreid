package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.Leaderboard
import androidx.compose.material.icons.outlined.SportsSoccer
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.FootballViewModel
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.MatchDetailScreen
import com.example.ui.screens.MatchesFeedScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.screens.StandingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.KoooraLiveTheme
import com.example.ui.theme.PitchGreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KoooraLiveTheme {
                KoooraApp()
            }
        }
    }
}

@Composable
fun KoooraApp(
    viewModel: FootballViewModel = viewModel()
) {
    val selectedMatch by viewModel.selectedMatch.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedBottomTab.collectAsStateWithLifecycle()
    val matches by viewModel.filteredMatches.collectAsStateWithLifecycle()
    val allMatches by viewModel.filteredMatches.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteMatchIds.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDateFilter.collectAsStateWithLifecycle()
    val selectedStatus by viewModel.selectedStatusFilter.collectAsStateWithLifecycle()
    val selectedCompFilter by viewModel.selectedCompetitionFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val goalAlert by viewModel.goalAlert.collectAsStateWithLifecycle()
    val isLiveSimActive by viewModel.isLiveSimulationActive.collectAsStateWithLifecycle()
    val standingsCompId by viewModel.selectedStandingsCompetition.collectAsStateWithLifecycle()
    val standingsSubTab by viewModel.standingsSubTab.collectAsStateWithLifecycle()

    val standings = remember(standingsCompId) { viewModel.getStandings(standingsCompId) }
    val topScorers = remember(standingsCompId) { viewModel.getTopScorers(standingsCompId) }
    val compMap = remember(viewModel.competitions) { viewModel.competitions.associateBy { it.id } }

    if (selectedMatch != null) {
        val currentMatch = selectedMatch!!
        val comp = compMap[currentMatch.competitionId]
        MatchDetailScreen(
            match = currentMatch,
            competitionName = comp?.nameAr ?: "",
            flagEmoji = comp?.flag ?: "⚽",
            isFavorite = favoriteIds.contains(currentMatch.id),
            onFavoriteToggle = { viewModel.toggleFavorite(currentMatch.id) },
            onBack = { viewModel.closeMatchDetails() }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = DarkBackground,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    contentColor = PitchGreen,
                    tonalElevation = 6.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { viewModel.selectBottomTab(0) },
                        icon = {
                            Icon(
                                imageVector = if (selectedTab == 0) Icons.Filled.SportsSoccer else Icons.Outlined.SportsSoccer,
                                contentDescription = "المباريات"
                            )
                        },
                        label = {
                            Text(
                                text = "المباريات",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF022C1A),
                            selectedTextColor = PitchGreen,
                            indicatorColor = PitchGreen,
                            unselectedIconColor = DarkTextMuted,
                            unselectedTextColor = DarkTextMuted
                        ),
                        modifier = Modifier.testTag("nav_matches")
                    )

                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { viewModel.selectBottomTab(1) },
                        icon = {
                            Icon(
                                imageVector = if (selectedTab == 1) Icons.Filled.Leaderboard else Icons.Outlined.Leaderboard,
                                contentDescription = "الترتيب"
                            )
                        },
                        label = {
                            Text(
                                text = "الترتيب",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF022C1A),
                            selectedTextColor = PitchGreen,
                            indicatorColor = PitchGreen,
                            unselectedIconColor = DarkTextMuted,
                            unselectedTextColor = DarkTextMuted
                        ),
                        modifier = Modifier.testTag("nav_standings")
                    )

                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { viewModel.selectBottomTab(2) },
                        icon = {
                            Icon(
                                imageVector = if (selectedTab == 2) Icons.Filled.Article else Icons.Outlined.Article,
                                contentDescription = "الأخبار"
                            )
                        },
                        label = {
                            Text(
                                text = "الأخبار",
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF022C1A),
                            selectedTextColor = PitchGreen,
                            indicatorColor = PitchGreen,
                            unselectedIconColor = DarkTextMuted,
                            unselectedTextColor = DarkTextMuted
                        ),
                        modifier = Modifier.testTag("nav_news")
                    )

                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { viewModel.selectBottomTab(3) },
                        icon = {
                            Icon(
                                imageVector = if (selectedTab == 3) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                contentDescription = "المفضلة"
                            )
                        },
                        label = {
                            Text(
                                text = "المفضلة",
                                fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF022C1A),
                            selectedTextColor = PitchGreen,
                            indicatorColor = PitchGreen,
                            unselectedIconColor = DarkTextMuted,
                            unselectedTextColor = DarkTextMuted
                        ),
                        modifier = Modifier.testTag("nav_favorites")
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (selectedTab) {
                    0 -> MatchesFeedScreen(
                        matches = matches,
                        competitions = viewModel.competitions,
                        favoriteIds = favoriteIds,
                        selectedDate = selectedDate,
                        onSelectDate = { viewModel.selectDateFilter(it) },
                        selectedStatus = selectedStatus,
                        onSelectStatus = { viewModel.selectStatusFilter(it) },
                        selectedCompetitionId = selectedCompFilter,
                        onSelectCompetition = { viewModel.selectCompetitionFilter(it) },
                        searchQuery = searchQuery,
                        onSearchChange = { viewModel.updateSearchQuery(it) },
                        goalAlert = goalAlert,
                        onDismissGoalAlert = { viewModel.dismissGoalAlert() },
                        isLiveSimActive = isLiveSimActive,
                        onToggleLiveSim = { viewModel.toggleLiveSimulation() },
                        onSimulateGoal = { viewModel.triggerSimulatedGoal() },
                        onSelectMatch = { viewModel.openMatchDetails(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                    1 -> StandingsScreen(
                        competitions = viewModel.competitions,
                        selectedCompetitionId = standingsCompId,
                        onSelectCompetition = { viewModel.selectStandingsCompetition(it) },
                        subTab = standingsSubTab,
                        onSelectSubTab = { viewModel.setStandingsSubTab(it) },
                        standings = standings,
                        topScorers = topScorers
                    )
                    2 -> NewsScreen(
                        newsList = viewModel.newsList
                    )
                    3 -> FavoritesScreen(
                        matches = allMatches,
                        favoriteIds = favoriteIds,
                        competitions = viewModel.competitions,
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onSelectMatch = { viewModel.openMatchDetails(it) },
                        onExploreClick = { viewModel.selectBottomTab(0) }
                    )
                }
            }
        }
    }
}
